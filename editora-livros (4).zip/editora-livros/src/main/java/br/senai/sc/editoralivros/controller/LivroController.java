package br.senai.sc.editoralivros.controller;

import br.senai.sc.editoralivros.dto.LivroDTO;
import br.senai.sc.editoralivros.model.entity.Autor;
import br.senai.sc.editoralivros.model.entity.Livro;
import br.senai.sc.editoralivros.model.entity.Status;
import br.senai.sc.editoralivros.model.service.LivroService;
import com.fasterxml.jackson.databind.util.BeanUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@RequestMapping("/editora-livros-api/livro")
@Controller
public class LivroController {

    private LivroService livroService;

    @GetMapping("/get/{isbn}")
    public ResponseEntity<List<Livro>> findByIdAndStatus(@PathVariable(value = "isbn") Long isbn) {
        return ResponseEntity.status(HttpStatus.OK).body(
                livroService.findByIsbnAndStatus(isbn, Status.APROVADO));
    }

    @PostMapping
    public ResponseEntity<Object> save(
            @RequestBody @Valid LivroDTO livroDto) {
        if (livroService.existsById(livroDto.getIsbn())){
            return ResponseEntity.status(HttpStatus.CONFLICT).body(
            "Há um livro com o ISBN " + livroDto.getIsbn() + " cadastrado.");
        }
        Livro livroModel = new Livro();
        livroModel.setStatus(Status.AGUARDANDO_REVISAO);
        BeanUtils.copyProperties(livroDto,livroModel);
        return ResponseEntity.status(HttpStatus.OK).body(
                livroService.save(livroModel));
    }

    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<Object> findById(
            @PathVariable(value = "isbn") Long isbn) {
        Optional<Livro> livroOptional =  livroService.findById(isbn);
        if (livroOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    "O livro de ISBN " + isbn + " não foi encontrado.");
        }
        return ResponseEntity.status(HttpStatus.FOUND).body(
                livroOptional.get());
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Livro>> findByStatus(
            @PathVariable(value = "status") Status status) {
        return ResponseEntity.status(HttpStatus.FOUND).body(
                livroService.findByStatus(status));
    }

    @GetMapping("/autor/{autor}")
    public ResponseEntity<List<Livro>> findByAutor(
            @PathVariable(value = "autor") Autor autor) {
        return ResponseEntity.status(HttpStatus.FOUND).body(
                livroService.findByAutor(autor));
    }

    @GetMapping
    public ResponseEntity<List<Livro>> findAll() {
        return ResponseEntity.status(HttpStatus.FOUND).body(
                livroService.findAll());
    }

    @DeleteMapping("/{isbn}")
    public ResponseEntity<Object> deleteById(
            @PathVariable(value = "isbn") Long isbn) {
        if (livroService.existsById(isbn)) {
            livroService.deleteById(isbn);
            return ResponseEntity.status(HttpStatus.OK).body(
                    "Livro deletado!");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                "Livro não encontrado.");
    }
    @PutMapping
    public ResponseEntity<Object> update(
            @RequestBody @Valid LivroDTO livroDto) {
        if (!livroService.existsById(livroDto.getIsbn())){
            return ResponseEntity.status(HttpStatus.CONFLICT).body(
                    "Livro não encontrado.");
        }
        Livro livroModel = livroService.findById(livroDto.getIsbn()).get();
        BeanUtils.copyProperties(livroDto,livroModel);
        return ResponseEntity.status(HttpStatus.OK).body(
                livroService.save(livroModel));
    }
}
