package br.senai.sc.editoralivros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EditoraLivroApplicationTests {

	@Test
	void contextLoads() {
	}

}
