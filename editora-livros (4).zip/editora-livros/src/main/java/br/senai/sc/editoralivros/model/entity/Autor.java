package br.senai.sc.editoralivros.model.entity;

import lombok.AllArgsConstructor;

import javax.persistence.Entity;

@AllArgsConstructor
@Entity
public class Autor extends Pessoa {

}
