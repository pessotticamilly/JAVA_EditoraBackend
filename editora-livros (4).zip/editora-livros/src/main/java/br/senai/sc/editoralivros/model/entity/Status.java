package br.senai.sc.editoralivros.model.entity;

public enum Status {
    AGUARDANDO_REVISAO(),
    EM_REVISAO(),
    APROVADO(),
    AGUARDANDO_EDICAO(),
    REPROVADO(),
    PUBLICADO();
//    String nome;
}
