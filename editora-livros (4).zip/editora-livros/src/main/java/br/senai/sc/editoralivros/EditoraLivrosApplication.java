package br.senai.sc.editoralivros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EditoraLivrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EditoraLivrosApplication.class, args);
	}

}
